---
layout: page
title: Welcome to Sangeet.ai's Blog!
---

Sangeet.ai's Blog uses a minimalist Jekyll theme. The purpose of this theme is to provide a simple, clean, content-focused blogging platform for your personal site or blog. Below you can find everything you need to get started.

### Getting Started

[Getting Started]({{ site.github.url }}{% post_url 2018-01-01-getting-started %}): getting started with installing this blog for your own stories, whether you are completely new to using Jekyll, or simply just migrating to a new Jekyll theme.

### Example Content

[Text and Formatting]({{ site.github.url }}{% post_url 2018-01-10-text-formatting-examples %})