---
layout: post
title: "About the Author"
author: "Sangeet Moy Das"
categories: journal
tags: [documentation,sample]
image: cutting.jpg
---

Hi there! I'm Sangeet. I’m a Computer Science Grad working as a Data Scientist with Mu Sigma Inc.
