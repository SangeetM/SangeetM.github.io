---
layout: post
title: "Welcome to Sangeet.ai's Blog!"
author: "Sangeet Moy Das"
categories: journal
tags: [documentation,sample]
image: mountains.jpg
---

Sangeet.ai's Blog uses a minimalist Jekyll theme. The purpose of this theme is to provide a simple, clean, content-focused blogging platform for your personal site or blog. Below you can find everything you need to get started.

## Content

[Text and Formatting]({{ site.github.url }}{% post_url 2018-01-10-text-formatting-examples %})